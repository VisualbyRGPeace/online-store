"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useQuery } from "@/hooks/use-query";
import { FREE_LABEL, PAID_LABEL } from "@/lib/site-config";
import { listCategories, listProducts } from "@/services/product-service";
import { ProductGrid } from "@/components/product-card";
import { SearchBox } from "@/components/search-box";
import { EmptyState, ErrorState, ProductGridSkeleton } from "@/components/ui/states";

type Kind = "free" | "paid";
const chip = "rounded-full border px-3.5 py-1.5 text-sm font-medium transition";
const on = "border-black bg-black text-white";
const off = "border-slate-200 bg-white text-slate-600 hover:border-slate-400 hover:text-black";

function buildHref(base: string, opts: { category?: string; type?: Kind; q?: string; page?: number }) {
  const q = new URLSearchParams();
  if (opts.q) q.set("q", opts.q);
  if (opts.type) q.set("type", opts.type);
  if (opts.category) q.set("category", opts.category);
  if (opts.page && opts.page > 1) q.set("page", String(opts.page));
  const s = q.toString();
  return s ? `${base}?${s}` : base;
}

/** The browsing page: search, filters, grid, pagination. `lead` is shown to the left of the search box. */
export function ProductsView({
  base = "/products/",
  lead,
  showSearch = true,
  anchor,
}: {
  base?: string;
  lead?: React.ReactNode;
  showSearch?: boolean;
  anchor?: string; // id of the section: page changes scroll back to it
}) {
  const params = useSearchParams();
  const page = Math.max(1, Number.parseInt(params?.get("page") ?? "1", 10) || 1);
  const category = params?.get("category") ?? undefined;
  const q = params?.get("q")?.slice(0, 100) || undefined;
  const typeParam = params?.get("type");
  const type: Kind | undefined = typeParam === "free" || typeParam === "paid" ? typeParam : undefined;

  const categories = useQuery("categories", listCategories);
  const list = useQuery(`products:${page}:${category ?? ""}:${type ?? ""}:${q ?? ""}`, () =>
    listProducts({ page, categorySlug: category, kind: type, q }),
  );

  return (
    <div>
      {(lead || showSearch) && (
        <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          {lead ?? <span />}
          {showSearch && <SearchBox key={q ?? ""} base={base} defaultValue={q ?? ""} anchor={anchor} className="w-full sm:max-w-sm" />}
        </div>
      )}

      <div className="mb-3 flex flex-wrap gap-2">
        <Link scroll={false} href={buildHref(base, { category, q })} className={`${chip} ${!type ? on : off}`}>Tất cả</Link>
        <Link scroll={false} href={buildHref(base, { category, q, type: "free" })} className={`${chip} ${type === "free" ? on : off}`}>{FREE_LABEL}</Link>
        <Link scroll={false} href={buildHref(base, { category, q, type: "paid" })} className={`${chip} ${type === "paid" ? on : off}`}>{PAID_LABEL}</Link>
      </div>
      {categories.status === "success" && categories.data.length > 0 && (
        <div className="mb-6 flex flex-wrap gap-2">
          <Link scroll={false} href={buildHref(base, { type, q })} className={`${chip} ${!category ? on : off}`}>Mọi danh mục</Link>
          {categories.data.map((c) => (
            <Link key={c.id} scroll={false} href={buildHref(base, { type, q, category: c.slug })} className={`${chip} ${category === c.slug ? on : off}`}>
              {c.name}
            </Link>
          ))}
        </div>
      )}

      {list.status === "success" && list.data.items.length > 0 && (
        <p className="mb-4 text-sm text-slate-500">
          {list.data.total} tài nguyên{q ? ` cho “${q}”` : ""}
        </p>
      )}
      {list.status === "loading" && <ProductGridSkeleton count={12} />}
      {list.status === "error" && <ErrorState />}
      {list.status === "success" && list.data.items.length === 0 && (
        <EmptyState title="Không tìm thấy tài nguyên" description="Thử từ khóa hoặc bộ lọc khác." href={base} actionLabel="Xem tất cả" />
      )}
      {list.status === "success" && list.data.items.length > 0 && (
        <>
          <ProductGrid products={list.data.items} />
          <Pagination page={page} totalPages={Math.ceil(list.data.total / list.data.pageSize)} href={(p) => `${buildHref(base, { category, type, q, page: p })}${anchor ? `#${anchor}` : ""}`} />
        </>
      )}
    </div>
  );
}

function Pagination({ page, totalPages, href }: { page: number; totalPages: number; href: (p: number) => string }) {
  if (totalPages <= 1) return null;
  const btn = "rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-medium hover:border-slate-400";
  return (
    <nav className="mt-12 flex items-center justify-center gap-4" aria-label="Phân trang">
      {page > 1 ? <Link href={href(page - 1)} className={btn}>← Trước</Link> : <span />}
      <span className="text-sm text-slate-500">Trang {page} / {totalPages}</span>
      {page < totalPages ? <Link href={href(page + 1)} className={btn}>Sau →</Link> : <span />}
    </nav>
  );
}
