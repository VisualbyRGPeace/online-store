@echo off
setlocal
set "DEST=%LOCALAPPDATA%\FolderOpen"

if not exist "%DEST%" mkdir "%DEST%"
copy /Y "%~dp0open.vbs" "%DEST%\open.vbs" >nul
copy /Y "%~dp0open.ps1" "%DEST%\open.ps1" >nul

reg add "HKCU\Software\Classes\folderopen" /ve /t REG_SZ /d "URL:Folder Open" /f >nul
reg add "HKCU\Software\Classes\folderopen" /v "URL Protocol" /t REG_SZ /d "" /f >nul
reg add "HKCU\Software\Classes\folderopen\shell\open\command" /ve /t REG_SZ /d "wscript.exe \"%DEST%\open.vbs\" \"%%1\"" /f >nul

if errorlevel 1 (
  echo Cai dat that bai.
) else (
  echo Da cai dat xong. Quay lai web va bam nut Mo.
)
pause
