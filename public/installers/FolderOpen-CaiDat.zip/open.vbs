Option Explicit
Dim arg, re, fso, dir, sh

If WScript.Arguments.Count = 0 Then WScript.Quit

arg = WScript.Arguments(0)

' Chi nhan ky tu an toan cua duong dan da ma hoa, tu choi moi thu khac.
Set re = New RegExp
re.Pattern = "^folderopen:[A-Za-z0-9%._~!*'()\-]+/?$"
If Not re.Test(arg) Then WScript.Quit

Set fso = CreateObject("Scripting.FileSystemObject")
dir = fso.GetParentFolderName(WScript.ScriptFullName)
Set sh = CreateObject("WScript.Shell")
sh.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & dir & "\open.ps1"" """ & arg & """", 0, False
