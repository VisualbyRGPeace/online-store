param([string]$Url)

if (-not $Url) { exit }

$raw = ($Url -replace '^folderopen:', '').TrimEnd('/')
try { $path = [System.Uri]::UnescapeDataString($raw) } catch { exit }

# Chi mo duong dan o dia (C:\...), khong mo duong dan mang \\may-chu.
if ($path -notmatch '^[A-Za-z]:[\\/]') { exit }
if ($path.Contains('"')) { exit }

$path = $path -replace '/', '\'
if ($path.Length -gt 3) { $path = $path.TrimEnd('\') }

# Chi mo thu muc that su ton tai, khong bao gio chay tep.
if (-not (Test-Path -LiteralPath $path -PathType Container)) { exit }

Start-Process -FilePath 'explorer.exe' -ArgumentList ('"' + $path + '"')
