@echo off
reg delete "HKCU\Software\Classes\folderopen" /f >nul 2>&1
rmdir /S /Q "%LOCALAPPDATA%\FolderOpen" >nul 2>&1
echo Da go cai dat.
pause
